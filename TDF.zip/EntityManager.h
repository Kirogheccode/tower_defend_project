#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <map>
#include <memory>
#include <functional>

class Entity;

using namespace std;
using namespace sf;

typedef vector<shared_ptr<Entity>> EntityVec;
typedef map<string, EntityVec> EntityMap;

class EntityManager
{
	friend class Game;

	EntityVec m_entities;
	EntityMap m_entityMap;
	size_t m_totalEntites = 0;

public: 
	EntityManager();

	shared_ptr<Entity> addEntity(const string& tag);

	EntityVec& getEntities();

	EntityVec getEntities(const string& tag);
};